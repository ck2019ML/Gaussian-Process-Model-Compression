Requires the [GPML toolbox](http://gaussianprocess.org/gpml/code/matlab/doc/)

Code is partially based on [GPs-for-long-range-forecatsing](https://github.com/ck2019ML/GPs-for-long-range-forecatsing.git)
